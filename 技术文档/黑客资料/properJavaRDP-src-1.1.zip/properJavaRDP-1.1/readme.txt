properJavaRDP

Copyright (c) 2005 Propero Ltd <www.propero.net>

August 2005

properJavaRDP is an open source Java RDP client for Windows Terminal
Server. It is based on rdesktop, a SourceForge project. properJavaRDP
runs on Java 1.1 up (optimised for 1.4). It also includes log4j-java1.1.

properJavaRDP was developed at Propero Ltd <www.propero.net> by Phil
Carmalt as part of our On Demand Framework for virtualised application
delivery. The 2005 keymapping and RDP5 extensions were developed by
Tom Elliott.

The project is hosted by Sourceforge at the following location:
http://sourceforge.net/projects/properjavardp

This software is released without warranty under the GPL (see
gpl.txt).

$Id: readme.txt 12 2007-05-11 11:49:09Z miha_vitorovic $

End.
